for (let i = 1; i <= 12; i++) {
  for (let j = 1; j <= 12; j++) {
    console.log(`${i} x ${j} = ${i * j}`);
  }
  console.log("------------------------");
}
