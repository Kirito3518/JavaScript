for (let i = 5; i >= 1; i--) {
  for (let j = 1; j <= i; j++) process.stdout.write("\t*");
  console.log();
}
